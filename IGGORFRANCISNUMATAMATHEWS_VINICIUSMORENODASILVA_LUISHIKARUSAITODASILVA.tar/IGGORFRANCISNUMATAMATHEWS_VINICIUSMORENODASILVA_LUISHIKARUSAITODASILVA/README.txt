
MAC0216 - Tecnicas de Programacao I
Integrantes do grupo:
	- Iggor Francis Numata Mathews
		NUSP: 10262572
	- Vinicius Moreno da Silva
		NUSP: 10297776
	- Luis Hikaru Saito da Silva
		NUSP: 10297780
Link do GitHub: https://github.com/iDoubleG/TecProg2017

Fase 1:
	As mudancas dos arquivos originais estao todas comentadas nos codigos,
nosso progresso pode ser acompanhado no GitHub.

Fase 2:
	Nesta fase foram criados arena.c e arena.h para uma melhor
implementacao do que foi pedido. As mudancas e criacoes relevantes foram
comentadas.